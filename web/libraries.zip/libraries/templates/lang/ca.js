/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'ca', {
	button: 'Plantilles',
	emptyListMsg: '(No hi ha plantilles definides)',
	insertOption: 'Reemplaça el contingut actual',
	options: 'Opcions de plantilla',
	selectPromptMsg: 'Seleccioneu una plantilla per usar a l\'editor<br>(per defecte s\'elimina el contingut actual):',
	title: 'Plantilles de contingut'
} );
