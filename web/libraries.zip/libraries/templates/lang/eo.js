/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'eo', {
	button: 'Ŝablonoj',
	emptyListMsg: '(Neniu ŝablono difinita)',
	insertOption: 'Anstataŭigi la nunan enhavon',
	options: 'Opcioj pri ŝablonoj',
	selectPromptMsg: 'Bonvolu selekti la ŝablonon por malfermi ĝin en la redaktilo',
	title: 'Enhavo de ŝablonoj'
} );
