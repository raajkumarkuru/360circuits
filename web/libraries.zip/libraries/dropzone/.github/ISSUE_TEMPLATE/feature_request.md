---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

Please submit feature requests in the Discussion tab! I will close issues that are feature requests.
