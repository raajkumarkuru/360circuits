import Dropzone from "../src/dropzone.js";

/// Make Dropzone a global variable.
window.Dropzone = Dropzone;

export default Dropzone;
export { Dropzone };
